package com.example.launcher

import android.app.ActivityManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.os.Bundle
import android.os.Debug
import android.view.Choreographer
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Launch
import androidx.compose.material.icons.filled.BrightnessHigh
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import com.example.core.AppLanguage
import com.example.core.LeviLogger
import com.example.core.LeviPreferences
import com.example.core.LeviStrings
import com.example.core.stringsFor
import com.example.model.LaunchMode
import com.example.model.LaunchStageStatus
import com.example.model.LaunchStepState
import com.example.tools.LeviModVaultManager
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LeviLabTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

class EmbeddedMinecraftActivity : ComponentActivity() {

    private var stagesState by mutableStateOf<List<LaunchStageStatus>>(emptyList())
    private var outcomeState by mutableStateOf<LaunchExecutionOutcome?>(null)
    private var isExecuting by mutableStateOf(true)
    private var isHostedSurfaceActive by mutableStateOf(false)
    private var hostedHandle: HostedActivityHandle? = null
    private var keepScreenOnState by mutableStateOf(true)
    private var showFloatingHudState by mutableStateOf(true)
    private var immersiveSurfaceState by mutableStateOf(true)
    private var launchAttemptId by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val logger = LeviLogger.getInstance(applicationContext)
        val preferences = LeviPreferences(applicationContext)
        val langName = intent.getStringExtra(EXTRA_LANGUAGE) ?: AppLanguage.AR.name
        val language = runCatching { AppLanguage.valueOf(langName) }.getOrDefault(AppLanguage.AR)
        val preferredPkg = intent.getStringExtra(EXTRA_PACKAGE_NAME)
        val preferredVaultId = intent.getStringExtra(EXTRA_VAULT_ID)
        val modeName = intent.getStringExtra(EXTRA_LAUNCH_MODE) ?: LaunchMode.DIRECT_NATIVE.name
        val launchMode = runCatching { LaunchMode.valueOf(modeName) }.getOrDefault(LaunchMode.DIRECT_NATIVE)
        val verifyCache = intent.getBooleanExtra(EXTRA_VERIFY_CACHE, true)
        keepScreenOnState = intent.getBooleanExtra(EXTRA_KEEP_SCREEN_ON, true)
        showFloatingHudState = intent.getBooleanExtra(EXTRA_SHOW_GAME_HUD, true)
        immersiveSurfaceState = intent.getBooleanExtra(EXTRA_IMMERSIVE_SURFACE, true)
        val loadCustomMods = intent.getBooleanExtra(EXTRA_LOAD_CUSTOM_MODS, false)
        val engineOptions = EngineLaunchOptions(
            allowCustomApplication = intent.getBooleanExtra(EXTRA_ALLOW_CUSTOM_APP, true),
            bootstrapContentProviders = intent.getBooleanExtra(EXTRA_BOOTSTRAP_PROVIDERS, true),
            strictVaultIsolation = intent.getBooleanExtra(EXTRA_STRICT_VAULT_ISOLATION, true)
        )
        val strings = stringsFor(language)

        applyKeepScreenOn(keepScreenOnState)
        onBackPressedDispatcher.addCallback(
            this,
            object : OnBackPressedCallback(true) {
                override fun handleOnBackPressed() {
                    val handle = hostedHandle
                    if (isHostedSurfaceActive && handle != null && handle.dispatchBackPressed()) {
                        return
                    }
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        )

        logger.info(
            "HOST",
            "Host console started (mode=${launchMode.name}, pkg=${preferredPkg ?: "auto"}, vault=${preferredVaultId ?: "none"}, hud=$showFloatingHudState, keepAwake=$keepScreenOnState, mods=$loadCustomMods, allowApp=${engineOptions.allowCustomApplication}, providers=${engineOptions.bootstrapContentProviders}, strictIso=${engineOptions.strictVaultIsolation}, immersive=$immersiveSurfaceState)"
        )

        setContent {
            LeviLabTheme(language = language) {
                LaunchedEffect(launchAttemptId) {
                    isExecuting = true
                    isHostedSurfaceActive = false
                    outcomeState = null
                    val customModPaths = if (loadCustomMods) {
                        withContext(Dispatchers.IO) {
                            val enabledIds = runCatching { preferences.enabledModIdsFlow.first() }.getOrDefault(emptySet())
                            LeviModVaultManager.getEnabledValidModPaths(applicationContext, enabledIds)
                        }
                    } else {
                        emptyList()
                    }

                    val outcome = InProcessLaunchCoordinator.executeVerifiedLaunch(
                        activityContext = this@EmbeddedMinecraftActivity,
                        preferredPackageName = preferredPkg,
                        preferredVaultId = preferredVaultId,
                        verifyCacheBeforeLaunch = verifyCache,
                        launchMode = launchMode,
                        customNativeModPaths = customModPaths,
                        engineOptions = engineOptions,
                        strings = strings,
                        logger = logger,
                        onStageUpdate = { updated -> stagesState = updated }
                    )
                    outcomeState = outcome
                    isExecuting = false
                    if (outcome.hostedInProcess && outcome.hostedHandle != null) {
                        hostedHandle = outcome.hostedHandle
                        isHostedSurfaceActive = true
                        applyImmersiveSystemBars(immersiveSurfaceState)
                    } else {
                        applyImmersiveSystemBars(false)
                    }
                    outcome.historyEntry?.let { entry ->
                        withContext(Dispatchers.IO) {
                            preferences.appendLaunchHistory(entry)
                        }
                    }
                }

                if (isHostedSurfaceActive && outcomeState?.failure == null) {
                    Box(modifier = Modifier.fillMaxSize()) {
                        if (showFloatingHudState) {
                            FloatingGameHudOverlay(
                                strings = strings,
                                keepScreenOn = keepScreenOnState,
                                onToggleKeepScreenOn = {
                                    keepScreenOnState = !keepScreenOnState
                                    applyKeepScreenOn(keepScreenOnState)
                                },
                                onHideHud = { showFloatingHudState = false },
                                onReturnToLab = { finish() }
                            )
                        }
                    }
                } else {
                    LaunchVerificationHostScreen(
                        strings = strings,
                        stages = stagesState,
                        outcome = outcomeState,
                        isExecuting = isExecuting,
                        onRelaunchGame = {
                            val pkg = outcomeState?.targetPackage
                            if (pkg != null && !pkg.isVaultApk) {
                                val ok = InProcessLaunchCoordinator.launchInstalledPackage(this, pkg, logger)
                                if (ok) {
                                    Toast.makeText(this, strings.embeddedDirectSuccessHint, Toast.LENGTH_SHORT).show()
                                } else {
                                    Toast.makeText(this, strings.embeddedFailureTitle, Toast.LENGTH_LONG).show()
                                }
                            }
                        },
                        onCleanDexAndRetry = {
                            lifecycleScope.launch {
                                val target = outcomeState?.targetPackage
                                withContext(Dispatchers.IO) {
                                    InProcessApkHostEngine.clearDexOptCache(applicationContext, target, logger)
                                }
                                launchAttemptId++
                            }
                        },
                        onShareFailure = {
                            copyDiagnosticReport(outcomeState, strings, logger)
                        },
                        onReturnToLab = { finish() }
                    )
                }
            }
        }
    }

    private fun applyKeepScreenOn(enabled: Boolean) {
        if (enabled) {
            window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        } else {
            window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }

    private fun applyImmersiveSystemBars(immersive: Boolean) {
        val w = window ?: return
        runCatching {
            val controller = WindowCompat.getInsetsController(w, w.decorView)
            if (immersive) {
                controller.systemBarsBehavior =
                    WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                controller.hide(WindowInsetsCompat.Type.systemBars())
            } else {
                controller.show(WindowInsetsCompat.Type.systemBars())
            }
        }
    }

    override fun onStart() {
        super.onStart()
        hostedHandle?.dispatchStart()
    }

    override fun onResume() {
        super.onResume()
        hostedHandle?.dispatchResume()
    }

    override fun onPause() {
        hostedHandle?.dispatchPause()
        super.onPause()
    }

    override fun onStop() {
        hostedHandle?.dispatchStop()
        super.onStop()
    }

    override fun onDestroy() {
        hostedHandle?.dispatchDestroy()
        hostedHandle = null
        super.onDestroy()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        hostedHandle?.dispatchNewIntent(intent)
    }

    override fun onLowMemory() {
        super.onLowMemory()
        hostedHandle?.dispatchLowMemory()
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        hostedHandle?.dispatchTrimMemory(level)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        hostedHandle?.dispatchWindowFocusChanged(hasFocus)
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        hostedHandle?.dispatchConfigurationChanged(newConfig)
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        val handle = hostedHandle
        if (handle != null && handle.dispatchKeyEvent(event)) {
            return true
        }
        return super.dispatchKeyEvent(event)
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        val handle = hostedHandle
        if (handle != null && handle.dispatchTouchEvent(ev)) {
            return true
        }
        return super.dispatchTouchEvent(ev)
    }

    override fun dispatchGenericMotionEvent(ev: MotionEvent): Boolean {
        val handle = hostedHandle
        if (handle != null && handle.dispatchGenericMotionEvent(ev)) {
            return true
        }
        return super.dispatchGenericMotionEvent(ev)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        @Suppress("DEPRECATION")
        super.onActivityResult(requestCode, resultCode, data)
        hostedHandle?.dispatchActivityResult(requestCode, resultCode, data)
    }

    private fun copyDiagnosticReport(
        outcome: LaunchExecutionOutcome?,
        strings: LeviStrings,
        logger: LeviLogger
    ) {
        val failure = outcome?.failure
        val report = buildString {
            appendLine("=== LeviLab Launch Diagnostic Report ===")
            appendLine("Mode: ${outcome?.mode?.name ?: "unknown"}")
            appendLine("Hosted In-Process: ${outcome?.hostedInProcess ?: false}")
            appendLine("Package: ${outcome?.targetPackage?.packageName ?: "unknown"}")
            appendLine("Source: ${if (outcome?.targetPackage?.isVaultApk == true) "APK Vault (${outcome.targetPackage.vaultId})" else "Installed Package"}")
            appendLine("Edition: ${outcome?.targetPackage?.edition?.name ?: "unknown"}")
            appendLine("Version: ${outcome?.targetPackage?.versionName ?: "unknown"} (code=${outcome?.targetPackage?.versionCode ?: 0})")
            appendLine("Failed Stage: ${failure?.failedStage ?: "none"}")
            appendLine("Exception: ${failure?.exceptionClass ?: "N/A"}")
            appendLine("Reason: ${failure?.reason ?: "N/A"}")
            if (!failure?.stackTracePreview.isNullOrBlank() && failure?.stackTracePreview != failure?.reason) {
                appendLine()
                appendLine("Stack Trace:")
                appendLine(failure?.stackTracePreview)
            }
            appendLine()
            appendLine("Stages:")
            outcome?.stages?.forEach { st ->
                appendLine("- [${st.state.name}] ${st.title}: ${st.detail}")
            }
            appendLine()
            appendLine("Recent Logs:")
            appendLine(logger.readFullFileText().lines().takeLast(60).joinToString("\n"))
        }
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("LeviLab Launch Report", report))
        Toast.makeText(this, strings.copiedToast, Toast.LENGTH_SHORT).show()
    }

    companion object {
        const val EXTRA_PACKAGE_NAME = "extra_package_name"
        const val EXTRA_VAULT_ID = "extra_vault_id"
        const val EXTRA_LANGUAGE = "extra_language"
        const val EXTRA_LAUNCH_MODE = "extra_launch_mode"
        const val EXTRA_VERIFY_CACHE = "extra_verify_cache"
        const val EXTRA_PREFER_DIRECT_APK = "extra_prefer_direct_apk"
        const val EXTRA_KEEP_SCREEN_ON = "extra_keep_screen_on"
        const val EXTRA_SHOW_GAME_HUD = "extra_show_game_hud"
        const val EXTRA_LOAD_CUSTOM_MODS = "extra_load_custom_mods"
        const val EXTRA_ALLOW_CUSTOM_APP = "extra_allow_custom_app"
        const val EXTRA_BOOTSTRAP_PROVIDERS = "extra_bootstrap_providers"
        const val EXTRA_STRICT_VAULT_ISOLATION = "extra_strict_vault_isolation"
        const val EXTRA_IMMERSIVE_SURFACE = "extra_immersive_surface"
    }
}

@Composable
private fun FloatingGameHudOverlay(
    strings: LeviStrings,
    keepScreenOn: Boolean,
    onToggleKeepScreenOn: () -> Unit,
    onHideHud: () -> Unit,
    onReturnToLab: () -> Unit
) {
    val context = LocalContext.current
    var expanded by remember { mutableStateOf(false) }
    var offsetX by remember { mutableFloatStateOf(24f) }
    var offsetY by remember { mutableFloatStateOf(24f) }
    var fps by remember { mutableIntStateOf(60) }
    var freeRamMb by remember { mutableLongStateOf(0L) }
    var nativeHeapMb by remember { mutableLongStateOf(0L) }
    var elapsedSeconds by remember { mutableLongStateOf(0L) }

    DisposableEffect(Unit) {
        var frameCount = 0
        var lastBucketNs = System.nanoTime()
        val choreographer = runCatching { Choreographer.getInstance() }.getOrNull()
        val callback = object : Choreographer.FrameCallback {
            override fun doFrame(frameTimeNanos: Long) {
                frameCount++
                val deltaNs = frameTimeNanos - lastBucketNs
                if (deltaNs >= 1_000_000_000L) {
                    fps = ((frameCount * 1_000_000_000.0) / deltaNs).roundToInt().coerceIn(0, 240)
                    frameCount = 0
                    lastBucketNs = frameTimeNanos
                }
                choreographer?.postFrameCallback(this)
            }
        }
        choreographer?.postFrameCallback(callback)
        onDispose {
            choreographer?.removeFrameCallback(callback)
        }
    }

    LaunchedEffect(Unit) {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        val startMs = System.currentTimeMillis()
        while (true) {
            if (am != null) {
                val mi = ActivityManager.MemoryInfo()
                am.getMemoryInfo(mi)
                freeRamMb = mi.availMem / (1024L * 1024L)
            }
            nativeHeapMb = Debug.getNativeHeapAllocatedSize() / (1024L * 1024L)
            elapsedSeconds = ((System.currentTimeMillis() - startMs) / 1000L).coerceAtLeast(0L)
            delay(1000L)
        }
    }

    val mins = elapsedSeconds / 60L
    val secs = elapsedSeconds % 60L
    val timerText = String.format(java.util.Locale.US, "%02d:%02d", mins, secs)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
    ) {
        Surface(
            color = MaterialTheme.colorScheme.surface.copy(alpha = 0.86f),
            shape = MaterialTheme.shapes.large,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.65f)),
            shadowElevation = 6.dp,
            modifier = Modifier
                .offset { IntOffset(offsetX.roundToInt(), offsetY.roundToInt()) }
                .pointerInput(Unit) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        offsetX = (offsetX + dragAmount.x).coerceAtLeast(0f)
                        offsetY = (offsetY + dragAmount.y).coerceAtLeast(0f)
                    }
                }
                .testTag("floating_game_hud")
        ) {
            if (!expanded) {
                Row(
                    modifier = Modifier
                        .clickable { expanded = true }
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Speed,
                        contentDescription = strings.hudFpsLabel,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = "$fps ${strings.hudFpsLabel} • $timerText",
                        style = MaterialTheme.typography.labelMedium,
                        fontFamily = JetBrainsMonoFontFamily,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            } else {
                Column(
                    modifier = Modifier
                        .widthIn(min = 220.dp, max = 280.dp)
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "LeviLab HUD",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.clickable { expanded = false }
                        )
                        Row {
                            IconButton(
                                onClick = { expanded = false },
                                modifier = Modifier.size(28.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Speed,
                                    contentDescription = "Collapse HUD",
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                            IconButton(
                                onClick = onHideHud,
                                modifier = Modifier.size(28.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = strings.closeButton,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }

                    Text(
                        text = "${strings.hudFpsLabel}: $fps | ${strings.hudSessionLabel}: $timerText",
                        style = MaterialTheme.typography.labelSmall,
                        fontFamily = JetBrainsMonoFontFamily,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "${strings.hudRamFreeLabel}: ${freeRamMb}MB | ${strings.hudNativeHeapLabel}: ${nativeHeapMb}MB",
                        style = MaterialTheme.typography.labelSmall,
                        fontFamily = JetBrainsMonoFontFamily,
                        color = MaterialTheme.colorScheme.secondary
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        OutlinedButton(
                            onClick = onToggleKeepScreenOn,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Default.BrightnessHigh,
                                contentDescription = strings.hudKeepAwakeShort,
                                tint = if (keepScreenOn) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.size(4.dp))
                            Text(
                                text = strings.hudKeepAwakeShort,
                                style = MaterialTheme.typography.labelSmall,
                                maxLines = 1
                            )
                        }
                        TextButton(onClick = onReturnToLab) {
                            Text(
                                text = strings.hudReturnToLabLabel,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.error
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun LaunchVerificationHostScreen(
    strings: LeviStrings,
    stages: List<LaunchStageStatus>,
    outcome: LaunchExecutionOutcome?,
    isExecuting: Boolean,
    onRelaunchGame: () -> Unit,
    onCleanDexAndRetry: () -> Unit,
    onShareFailure: () -> Unit,
    onReturnToLab: () -> Unit
) {
    val failure = outcome?.failure
    val directSuccess = (outcome?.gameLaunchedExternally == true || outcome?.hostedInProcess == true) && failure == null
    val targetNotVault = outcome?.targetPackage != null && !outcome.targetPackage.isVaultApk

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .windowInsetsPadding(WindowInsets.safeDrawing)
            .padding(16.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 680.dp)
                .fillMaxWidth()
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.VerifiedUser,
                        contentDescription = strings.embeddedDirectHostTitle,
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = strings.embeddedDirectHostTitle,
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                }
                OutlinedButton(
                    onClick = onReturnToLab,
                    modifier = Modifier.testTag("embedded_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = strings.embeddedBackToLabButton,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.size(6.dp))
                    Text(strings.embeddedBackToLabButton)
                }
            }

            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        if (isExecuting) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                strokeWidth = 2.dp
                            )
                        }
                        Text(
                            text = strings.embeddedRunningStages,
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    stages.forEach { stage ->
                        StageRow(stage = stage)
                    }
                }
            }

            if (directSuccess) {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)
                    ),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = strings.embeddedDirectSuccessHint,
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        if (targetNotVault) {
                            Button(
                                onClick = onRelaunchGame,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("embedded_relaunch_button")
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.Launch,
                                    contentDescription = strings.embeddedOpenExternalButton,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.size(6.dp))
                                Text(strings.embeddedOpenExternalButton)
                            }
                        }
                    }
                }
            }

            if (failure != null) {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.errorContainer
                    ),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.error)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = strings.embeddedFailureTitle,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onErrorContainer
                        )
                        Text(
                            text = "${failure.failedStage} — ${failure.exceptionClass}",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.onErrorContainer
                        )
                        Surface(
                            color = MaterialTheme.colorScheme.background.copy(alpha = 0.65f),
                            shape = MaterialTheme.shapes.small
                        ) {
                            Text(
                                text = failure.reason,
                                style = MaterialTheme.typography.bodyMedium,
                                fontFamily = JetBrainsMonoFontFamily,
                                color = MaterialTheme.colorScheme.onBackground,
                                modifier = Modifier.padding(12.dp)
                            )
                        }
                        if (failure.stackTracePreview.isNotBlank() && failure.stackTracePreview != failure.reason) {
                            Surface(
                                color = MaterialTheme.colorScheme.background.copy(alpha = 0.45f),
                                shape = MaterialTheme.shapes.small
                            ) {
                                Text(
                                    text = failure.stackTracePreview,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontFamily = JetBrainsMonoFontFamily,
                                    color = MaterialTheme.colorScheme.onBackground,
                                    modifier = Modifier.padding(10.dp)
                                )
                            }
                        }
                        Text(
                            text = if (targetNotVault) strings.embeddedFallbackMessage else strings.embeddedVaultFallbackMessage,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onErrorContainer
                        )

                        if (failure.fallbackAvailable && targetNotVault) {
                            Button(
                                onClick = onRelaunchGame,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("embedded_fallback_official_button")
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.Launch,
                                    contentDescription = strings.embeddedOpenExternalButton,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.size(6.dp))
                                Text(strings.embeddedOpenExternalButton)
                            }
                        }

                        Button(
                            onClick = onCleanDexAndRetry,
                            enabled = !isExecuting,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("embedded_retry_clean_dex_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = strings.embeddedRetryCleanDexButton,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.size(6.dp))
                            Text(strings.embeddedRetryCleanDexButton)
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            OutlinedButton(
                                onClick = onReturnToLab,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("embedded_error_return_button")
                            ) {
                                Text(strings.embeddedBackToLabButton)
                            }
                            OutlinedButton(
                                onClick = onShareFailure,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("embedded_share_failure_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ContentCopy,
                                    contentDescription = strings.embeddedShareReportButton,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.size(6.dp))
                                Text(strings.embeddedShareReportButton)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StageRow(stage: LaunchStageStatus) {
    val icon = when (stage.state) {
        LaunchStepState.PENDING -> Icons.Default.RadioButtonUnchecked
        LaunchStepState.RUNNING -> Icons.Default.HourglassTop
        LaunchStepState.PASSED -> Icons.Default.CheckCircle
        LaunchStepState.FAILED -> Icons.Default.Error
    }
    val tint = when (stage.state) {
        LaunchStepState.PENDING -> MaterialTheme.colorScheme.onSurfaceVariant
        LaunchStepState.RUNNING -> MaterialTheme.colorScheme.secondary
        LaunchStepState.PASSED -> MaterialTheme.colorScheme.primary
        LaunchStepState.FAILED -> MaterialTheme.colorScheme.error
    }

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalAlignment = Alignment.Top
    ) {
        Icon(
            imageVector = icon,
            contentDescription = stage.title,
            tint = tint,
            modifier = Modifier
                .padding(top = 2.dp)
                .size(18.dp)
        )
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = stage.title,
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurface
            )
            if (stage.detail.isNotBlank()) {
                Text(
                    text = stage.detail,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
