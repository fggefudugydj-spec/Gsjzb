package com.example.tools

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.example.core.LeviLogger
import com.example.engine.Elf64Parser
import com.example.engine.ElfValidator
import com.example.model.NativeModEntry
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest
import java.util.UUID

object LeviModVaultManager {

    private const val MODS_DIR = "mc_mods"

    fun modsRootDir(context: Context): File =
        File(context.filesDir, MODS_DIR).apply { mkdirs() }

    fun importNativeMod(
        context: Context,
        uri: Uri,
        enabledIds: Set<String>,
        logger: LeviLogger? = null
    ): Result<NativeModEntry> {
        return runCatching {
            val rawName = queryDisplayName(context, uri) ?: "mod_${UUID.randomUUID().toString().take(6)}.so"
            val cleanName = rawName.replace(Regex("[^a-zA-Z0-9._-]"), "_")
                .let { if (it.endsWith(".so", ignoreCase = true)) it else "$it.so" }

            val root = modsRootDir(context)
            val destFile = File(root, cleanName)
            val input = context.contentResolver.openInputStream(uri)
                ?: error("Cannot open selected .so file: $rawName")

            val digest = MessageDigest.getInstance("SHA-256")
            input.use { src ->
                FileOutputStream(destFile).use { out ->
                    val buf = ByteArray(32 * 1024)
                    while (true) {
                        val n = src.read(buf)
                        if (n <= 0) break
                        digest.update(buf, 0, n)
                        out.write(buf, 0, n)
                    }
                }
            }
            runCatching {
                destFile.setReadable(true, false)
                destFile.setReadOnly()
            }

            val shaShort = digest.digest().take(6).joinToString("") { "%02x".format(it) }
            val entry = inspectModFile(destFile, shaShort, isEnabled = cleanName in enabledIds)
            logger?.info(
                "MOD_VAULT",
                "Imported .so mod ${entry.fileName} (${entry.sizeBytes} bytes, arm64Elf=${entry.isValidArm64Elf}, syms=${entry.exportedSymbolsCount})"
            )
            entry
        }.onFailure { err ->
            logger?.error("MOD_VAULT", "Failed importing .so mod: ${err.message}", err)
        }
    }

    fun loadAllMods(context: Context, enabledIds: Set<String>): List<NativeModEntry> {
        val root = modsRootDir(context)
        val files = root.listFiles { f -> f.isFile && f.name.endsWith(".so", ignoreCase = true) } ?: return emptyList()
        return files.map { file ->
            val shaShort = computeFileShaShort(file)
            inspectModFile(file, shaShort, isEnabled = file.name in enabledIds)
        }.sortedBy { it.fileName.lowercase() }
    }

    fun getEnabledValidModPaths(context: Context, enabledIds: Set<String>): List<String> {
        return loadAllMods(context, enabledIds)
            .filter { it.isEnabled && it.isValidArm64Elf && File(it.filePath).isFile }
            .map { it.filePath }
    }

    fun deleteMod(context: Context, modId: String, logger: LeviLogger? = null): Boolean {
        val target = File(modsRootDir(context), modId)
        val deleted = target.exists() && target.delete()
        if (deleted) {
            logger?.info("MOD_VAULT", "Deleted native mod $modId")
        }
        return deleted
    }

    private fun inspectModFile(file: File, shaShort: String, isEnabled: Boolean): NativeModEntry {
        val elf = ElfValidator.validateLibrary(
            file = file,
            sourceOrigin = MODS_DIR,
            requireMinOneMb = false,
            requireArm64 = true
        )
        val dyn = if (elf.isValid) {
            runCatching { Elf64Parser.parseDynamicInfo(file) }.getOrNull()
        } else {
            null
        }
        return NativeModEntry(
            id = file.name,
            fileName = file.name,
            filePath = file.absolutePath,
            sha256Short = shaShort,
            sizeBytes = file.length(),
            isValidArm64Elf = elf.isValid && elf.isAArch64,
            dtNeeded = dyn?.dtNeeded.orEmpty(),
            exportedSymbolsCount = (dyn?.exportedEntrypoints?.size ?: 0) + (dyn?.jniSymbolCount ?: 0),
            validationNote = elf.validationNote,
            isEnabled = isEnabled
        )
    }

    private fun computeFileShaShort(file: File): String {
        return runCatching {
            val digest = MessageDigest.getInstance("SHA-256")
            file.inputStream().use { src ->
                val buf = ByteArray(16 * 1024)
                while (true) {
                    val n = src.read(buf)
                    if (n <= 0) break
                    digest.update(buf, 0, n)
                }
            }
            digest.digest().take(6).joinToString("") { "%02x".format(it) }
        }.getOrDefault("n/a")
    }

    private fun queryDisplayName(context: Context, uri: Uri): String? {
        val fromResolver = runCatching {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0) else null
            }
        }.getOrNull()
        return fromResolver?.takeIf { it.isNotBlank() }
            ?: uri.lastPathSegment?.substringAfterLast('/')?.takeIf { it.isNotBlank() }
    }
}
