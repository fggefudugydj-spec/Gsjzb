package com.example.tools

data class Coord3i(
    val x: Int,
    val y: Int,
    val z: Int
)

data class ChunkRegionResult(
    val chunkX: Int,
    val chunkZ: Int,
    val inChunkX: Int,
    val inChunkZ: Int,
    val regionX: Int,
    val regionZ: Int
) {
    val regionFileLabel: String get() = "r.$regionX.$regionZ.mca"
}

data class TicksConversionResult(
    val totalTicks: Long,
    val seconds: Double,
    val formattedRealTime: String,
    val bedrockDays: Long,
    val tickOfDay: Int,
    val dayPhase: String
)

data class XpCurveResult(
    val level: Int,
    val totalXpRequired: Long,
    val nextLevelXpCost: Int
)

object MinecraftCalculators {

    fun overworldToNether(x: Int, y: Int, z: Int): Coord3i =
        Coord3i(x = Math.floorDiv(x, 8), y = y, z = Math.floorDiv(z, 8))

    fun netherToOverworld(x: Int, y: Int, z: Int): Coord3i =
        Coord3i(x = x * 8, y = y, z = z * 8)

    fun blockToChunkAndRegion(x: Int, z: Int): ChunkRegionResult {
        val chunkX = Math.floorDiv(x, 16)
        val chunkZ = Math.floorDiv(z, 16)
        val inChunkX = Math.floorMod(x, 16)
        val inChunkZ = Math.floorMod(z, 16)
        val regionX = Math.floorDiv(chunkX, 32)
        val regionZ = Math.floorDiv(chunkZ, 32)
        return ChunkRegionResult(
            chunkX = chunkX,
            chunkZ = chunkZ,
            inChunkX = inChunkX,
            inChunkZ = inChunkZ,
            regionX = regionX,
            regionZ = regionZ
        )
    }

    fun ticksToBedrockTime(rawTicks: Long): TicksConversionResult {
        val ticks = rawTicks.coerceAtLeast(0L)
        val totalSeconds = ticks / 20.0
        val wholeSeconds = totalSeconds.toLong()
        val hours = wholeSeconds / 3600L
        val mins = (wholeSeconds % 3600L) / 60L
        val secs = wholeSeconds % 60L
        val formatted = if (hours > 0L) {
            String.format(java.util.Locale.US, "%d:%02d:%02d", hours, mins, secs)
        } else {
            String.format(java.util.Locale.US, "%02d:%02d", mins, secs)
        }

        val bedrockDays = ticks / 24_000L
        val tickOfDay = (ticks % 24_000L).toInt()
        val phase = when (tickOfDay) {
            in 0..999 -> "Sunrise / Dawn"
            in 1000..5999 -> "Morning"
            in 6000..11999 -> "Noon / Afternoon"
            in 12000..12999 -> "Sunset / Dusk"
            in 13000..17999 -> "Night"
            else -> "Midnight / Pre-Dawn"
        }

        return TicksConversionResult(
            totalTicks = ticks,
            seconds = totalSeconds,
            formattedRealTime = formatted,
            bedrockDays = bedrockDays,
            tickOfDay = tickOfDay,
            dayPhase = phase
        )
    }

    fun calculateXpForLevel(rawLevel: Int): XpCurveResult {
        val l = rawLevel.coerceIn(0, 21863)
        val totalXp: Long = when {
            l <= 16 -> l.toLong() * l.toLong() + 6L * l.toLong()
            l <= 31 -> ((2.5 * l * l) - (40.5 * l) + 360.0).toLong()
            else -> ((4.5 * l * l) - (162.5 * l) + 2220.0).toLong()
        }
        val nextLevelCost = when {
            l <= 15 -> 2 * l + 7
            l <= 30 -> 5 * l - 38
            else -> 9 * l - 158
        }
        return XpCurveResult(
            level = l,
            totalXpRequired = totalXp,
            nextLevelXpCost = nextLevelCost
        )
    }
}
